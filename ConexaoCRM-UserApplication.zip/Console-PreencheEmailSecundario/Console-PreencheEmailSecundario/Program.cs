﻿using Console_PreencheEmailSecundario.CRM;
using Console_PreencheEmailSecundario.Data;
using Console_PreencheEmailSecundario.Service;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_PreencheEmailSecundario
{
    internal class Program
    {
        static void Main(string[] args)
        {
            IOrganizationService svc = CRM.crmConection.getConection();
            ITracingService trace = new Tracer();

            EntityCollection contatos = ContatoData.BuscarContatos(svc);

            foreach (var item in contatos.Entities)
            {
                ContatoService.PreencheemailSecundario(item, svc, trace);
            }

        }
    }
}
