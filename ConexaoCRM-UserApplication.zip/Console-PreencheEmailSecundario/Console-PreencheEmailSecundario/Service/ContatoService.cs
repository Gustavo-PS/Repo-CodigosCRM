﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_PreencheEmailSecundario.Service
{
    public class ContatoService
    {
        public static void PreencheemailSecundario(Entity contato, IOrganizationService service, ITracingService tracer)
        {
            try
            {
                contato["bz_email_secundario"] = contato["emailaddress2"];
                service.Update(contato);
                tracer.Trace("Contato atualizado: " + contato.Id+ "| Campo: bz_email_secundario");

                contato["emailaddress2"] = null;
                service.Update(contato);
                tracer.Trace("Contato atualizado: " + contato.Id + "| Campo: emailaddress2 limpo");
            }
            catch (Exception e)
            {
                tracer.Trace("Erro no contato: " + contato.Id + " | Mensagem: " + e.Message);
            }
        }

    }
}
