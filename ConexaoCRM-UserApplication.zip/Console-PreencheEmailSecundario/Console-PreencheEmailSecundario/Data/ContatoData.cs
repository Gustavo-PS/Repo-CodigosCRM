﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_PreencheEmailSecundario.Data
{
    public class ContatoData
    {
        public static EntityCollection BuscarContatos(IOrganizationService service)
        {
            EntityCollection resultado = new EntityCollection();
            FetchExpression fetch = new FetchExpression();
            int page = 1;
            while (true)
            {
                fetch.Query = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' page='{page}'>
  <entity name='contact'>
    <attribute name='fullname' />
    <attribute name='contactid' />
    <attribute name='emailaddress2' />
    <attribute name='bz_email_secundario' />
    <order attribute='fullname' descending='false' />
    <filter type='and'>
      <condition attribute='emailaddress2' operator='not-null' />
    </filter>
  </entity>
</fetch>";

                EntityCollection result = service.RetrieveMultiple(fetch);
                if (result != null && result.Entities.Count > 0)
                {
                    foreach (Entity item in result.Entities)
                        resultado.Entities.Add(item);

                    page++;
                }
                else break;
            }
            return resultado;
        }
    }
}
