﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_PreencheEmailSecundario.CRM
{
    internal class crmConection
    {
        public static IOrganizationService getConection()
        {
            string ConnectionString = "AuthType = ClientSecret; " +
                  "ClientId=25467bf2-9bc1-44fb-bbf4-4ce032355248; " +
                  "ClientSecret=3jz7Q~ndGZm72wF-WRWPrPJ_7vzVpST3eBVBZ; " +
                  "Url = https://libbs.crm2.dynamics.com/;";

            CrmServiceClient svc = new CrmServiceClient(ConnectionString);

            if (svc.IsReady)
                return svc;
            else
                return null;
        }
    }
}
