﻿using Microsoft.Xrm.Sdk;
using System;
using System.IO;
using System.Reflection;

namespace Console_PreencheEmailSecundario.CRM
{
    public class Tracer : ITracingService
    {
        private readonly string arquivoDeLog;

        public Tracer()
        {
            this.arquivoDeLog = CaminhoDoArquivoLog();
        }
        private string CaminhoDoArquivoLog()
        {
            string LogPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + "\\Logs";
            if (!Directory.Exists(LogPath)) Directory.CreateDirectory(LogPath);
            LogPath += "\\";
            var nomeDoArquivo = DateTime.Now.ToString("yyyyMMdd");
            var contador = 1;
            var caminho = LogPath + nomeDoArquivo + contador.ToString("000") + ".txt";
            while (File.Exists(caminho))
            {
                contador++;
                caminho = LogPath + nomeDoArquivo + contador.ToString("000") + ".txt";
            }
            return caminho;
        }
        public void Trace(string format, params object[] args)
        {
            using (var log = new StreamWriter(arquivoDeLog, true))
            {
                log.WriteLine(string.Format(format, args));
            }
        }
    }
}
